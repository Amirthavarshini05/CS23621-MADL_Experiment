package com.example.recyclerviewdemo

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class FruitAdapter(
    private val fruits: MutableList<Fruit>,
    private val onItemClick: (Fruit) -> Unit,
    private val onDeleteClick: (Int) -> Unit
) : RecyclerView.Adapter<FruitAdapter.FruitViewHolder>() {

    // ViewHolder (holds one row)
    inner class FruitViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val tvEmoji: TextView = itemView.findViewById(R.id.tvEmoji)
        val tvFruitName: TextView = itemView.findViewById(R.id.tvFruitName)
        val btnDelete: ImageButton = itemView.findViewById(R.id.btnDelete)
    }

    // Create view
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FruitViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_fruit, parent, false)
        return FruitViewHolder(view)
    }

    // Bind data
    override fun onBindViewHolder(holder: FruitViewHolder, position: Int) {
        val fruit = fruits[position]

        holder.tvEmoji.text = fruit.emoji
        holder.tvFruitName.text = fruit.name

        // Click full item
        holder.itemView.setOnClickListener {
            onItemClick(fruit)
        }

        // Delete button click
        holder.btnDelete.setOnClickListener {
            val pos = holder.adapterPosition
            if (pos != RecyclerView.NO_POSITION) {
                onDeleteClick(pos)
            }
        }
    }

    // Count items
    override fun getItemCount(): Int = fruits.size

    // Add item
    fun addFruit(fruit: Fruit) {
        fruits.add(fruit)
        notifyItemInserted(fruits.size - 1)
    }

    // Remove item
    fun removeFruit(position: Int) {
        if (position in fruits.indices) {
            fruits.removeAt(position)
            notifyItemRemoved(position)
        }
    }
}