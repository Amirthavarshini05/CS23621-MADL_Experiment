package com.example.recyclerviewdemo

data class Fruit(
    val name: String,
    val emoji: String
)