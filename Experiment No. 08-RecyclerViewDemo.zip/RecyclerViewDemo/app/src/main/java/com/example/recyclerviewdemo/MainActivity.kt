package com.example.recyclerviewdemo

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var etFruitName: EditText
    private lateinit var btnAdd: Button
    private lateinit var tvItemCount: TextView
    private lateinit var adapter: FruitAdapter

    private val fruitList: MutableList<Fruit> = mutableListOf(
        Fruit("Apple", "🍎"),
        Fruit("Banana", "🍌"),
        Fruit("Cherry", "🍒"),
        Fruit("Mango", "🥭"),
        Fruit("Pineapple", "🍍")
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        recyclerView = findViewById(R.id.recyclerView)
        etFruitName = findViewById(R.id.etFruitName)
        btnAdd = findViewById(R.id.btnAdd)
        tvItemCount = findViewById(R.id.tvItemCount)

        adapter = FruitAdapter(
            fruits = fruitList,
            onItemClick = { fruit -> onFruitClicked(fruit) },
            onDeleteClick = { position -> onDeleteClicked(position) }
        )

        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = adapter

        updateItemCount()

        btnAdd.setOnClickListener {
            addFruit()
        }
    }

    private fun onFruitClicked(fruit: Fruit) {
        Toast.makeText(
            this,
            "${fruit.emoji} You tapped: ${fruit.name}",
            Toast.LENGTH_SHORT
        ).show()
    }

    private fun onDeleteClicked(position: Int) {
        val removed = fruitList[position]
        adapter.removeFruit(position)
        updateItemCount()

        Toast.makeText(
            this,
            "Removed: ${removed.name}",
            Toast.LENGTH_SHORT
        ).show()
    }

    private fun addFruit() {
        val name = etFruitName.text.toString().trim()

        if (name.isEmpty()) {
            etFruitName.error = "Please enter a fruit name"
            return
        }

        adapter.addFruit(Fruit(name, "🍎"))
        updateItemCount()

        etFruitName.setText("")
        recyclerView.scrollToPosition(fruitList.size - 1)

        Toast.makeText(this, "Added: $name", Toast.LENGTH_SHORT).show()
    }

    private fun updateItemCount() {
        val count = fruitList.size
        tvItemCount.text = "$count ${if (count == 1) "item" else "items"}"
    }
}